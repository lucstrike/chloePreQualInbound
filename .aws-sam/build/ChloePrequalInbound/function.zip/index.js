const { handler } = require("./src/functions/handler"); // ajuste o caminho se necessário

exports.handler = handler;
