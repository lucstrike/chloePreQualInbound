module.exports = {
  GHL_API_KEY: process.env.GHL_API_KEY,
  OPENAI_API_KEY: process.env.OPENAI_API_KEY,
  GHL_WEBHOOK_SECRET: process.env.GHL_WEBHOOK_SECRET,
};
